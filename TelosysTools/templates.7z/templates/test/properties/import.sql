INSERT INTO categorie (categoria,annomin,annomax,punti,puntimax,nrset,note,active) VALUES ('Piccoli amici',5,6,5,5,1,'11111',true);
INSERT INTO categorie (categoria,annomin,annomax,punti,puntimax,nrset,note,active) VALUES ('Media',6,7,15,15,2,'',true);
INSERT INTO categorie (categoria,annomin,annomax,punti,puntimax,nrset,note,active) VALUES ('Juniores',10,12,15,15,2,'',true);